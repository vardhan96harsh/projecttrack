
# ProjectTrack Backend (Node + Express + MongoDB)

## Quick Start
1) Install MongoDB locally or use Atlas. Create a database (it will auto-create).
2) Copy `.env.example` to `.env` and adjust:
```
MONGO_URI=mongodb://127.0.0.1:27017/projecttrack
JWT_SECRET=supersecret_change_me
PORT=3001
```
3) Install & seed:
```
npm install
npm run seed
npm run dev
```
- Admin credentials: **admin@demo.com / Pass@123**

## API (selected)
- `POST /api/auth/login` { email, password }
- `GET /api/companies` (auth) | `POST/PUT/DELETE` (admin)
- `GET /api/categories` (auth) | `POST/PUT/DELETE` (admin)
- `GET /api/projects?company=&category=` (auth) | `POST/PUT/DELETE` (admin)
- `GET /api/users` (admin) | `POST/PUT/DELETE` (admin)
- `POST /api/timesheets` (auth)
- `GET /api/timesheets` (auth — admin sees all, employee sees own) with filters: company, category, project, user, from, to, taskType
- `GET /api/reports/summary?dim=project|company|category|user&from=&to=` (admin)
- `GET /api/reports/export?...` -> CSV download (admin)
#   p r o j e c t t r a c k  
 